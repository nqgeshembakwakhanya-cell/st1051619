package com.mycompany.employeesales;


  public class EmployeeSales {

    public static void main(String[] args) {

        // Employee numbers (rows)
        int[] employees = {101111, 101122, 101133, 101144, 101155};

        // Two-dimensional array: rows = employees, columns = Sales 1..3
        int[][] sales = {
            {3000, 2000, 3500},
            {2500, 5500, 3500},
            {1100, 2000, 4500},
            {1700, 2700, 2500},
            {5000, 2900, 5900}
        };

        int[] totals = new int[employees.length];

        // Accumulate the total for each employee
        for (int r = 0; r < sales.length; r++) {
            for (int c = 0; c < sales[r].length; c++) {
                totals[r] += sales[r][c];
            }
        }

        // ---- Sales report ----
        System.out.println("**************************************");
        System.out.println("*        EMPLOYEE SALES REPORT       *");
        System.out.println("**************************************");
        System.out.printf("%-12s%10s%10s%10s%n", "", "SALES 1", "SALES 2", "SALES 3");

        for (int r = 0; r < sales.length; r++) {
            System.out.printf("%-12s", employees[r] + "-->");
            for (int c = 0; c < sales[r].length; c++) {
                System.out.printf("%10s", "R " + sales[r][c]);
            }
            System.out.println();
        }

        // ---- Total sales ----
        System.out.println();
        System.out.println("**************************************");
        System.out.println("*       EMPLOYEE TOTAL SALES         *");
        System.out.println("**************************************");

        for (int r = 0; r < employees.length; r++) {
            System.out.printf("%-12s%10s%n", employees[r] + "-->", "R " + totals[r] + ".0");
        }
    }
}


