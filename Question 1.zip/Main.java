import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        String[] names = { "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket" };
        int months = 3;
        int[][] sales = new int[names.length][months];

        for (int p = 0; p < names.length; p++)
        {
            for (int m = 0; m < months; m++)
            {
                System.out.print("Enter number of sales for month " + (m + 1)
                        + " for " + names[p] + " mattress: ");
                sales[p][m] = input.nextInt();
            }
            System.out.println();
        }

        IProducts report = new Product(names, sales);

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println();
        System.out.println("*****************************************");
        System.out.println("TOTAL PRODUCT SALES: " + report.GetTotalSales());
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", report.GetAverageSales());
        System.out.println("MOST POPULAR PRODUCT: " + report.GetMostPopularProduct());

        input.close();
    }
}
