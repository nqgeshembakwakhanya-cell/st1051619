public class Product implements IProducts
{
    private final String[] names;   // single-dimensional array
    private final int[][] sales;    // two-dimensional array [product][month]

    public Product(String[] names, int[][] sales)
    {
        this.names = names;
        this.sales = sales;
    }

    @Override
    public int GetTotalSales()
    {
        int total = 0;
        for (int p = 0; p < sales.length; p++)
            for (int m = 0; m < sales[p].length; m++)
                total += sales[p][m];
        return total;
    }

    @Override
    public double GetAverageSales()
    {
        int count = sales.length * sales[0].length;
        return (double) GetTotalSales() / count;
    }

    @Override
    public String GetMostPopularProduct()
    {
        int max = sales[0][0];
        int best = 0;
        for (int p = 0; p < sales.length; p++)
            for (int m = 0; m < sales[p].length; m++)
                if (sales[p][m] > max)
                {
                    max = sales[p][m];
                    best = p;
                }
        return names[best] + "(" + max + ")";
    }
}
