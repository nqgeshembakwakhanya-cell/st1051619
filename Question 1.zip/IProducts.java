public interface IProducts
{
    int GetTotalSales();
    double GetAverageSales();
    String GetMostPopularProduct();
}
