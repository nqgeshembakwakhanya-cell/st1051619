package productapp;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {

    private static final String[] PRODUCTS = {
        "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"
    };
    private static final String FILE_NAME = "data.txt";

    private final JTextField txtName = new JTextField(20);
    private final JComboBox<String> cmbProduct = new JComboBox<>(PRODUCTS);
    private final JTextField txtPrice = new JTextField(20);
    private final JButton btnProcess = new JButton("PROCESS");

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        buildMenu();
        buildForm();
        pack();
        setSize(450, 250);
        setLocationRelativeTo(null);
    }

    // Q.2.4 - menu system
    private void buildMenu() {
        JMenuBar bar = new JMenuBar();

        JMenu file = new JMenu("File");
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> System.exit(0));   // close the application
        file.add(exit);

        JMenu tools = new JMenu("Tools");
        JMenuItem process = new JMenuItem("Process");
        process.addActionListener(e -> processSale()); // same logic as the button
        JMenuItem clear = new JMenuItem("Clear");
        clear.addActionListener(e -> clearForm());
        tools.add(process);
        tools.add(clear);

        bar.add(file);
        bar.add(tools);
        setJMenuBar(bar);
    }

    // Q.2.1 / Q.2.2 - form layout
    private void buildForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0; c.gridy = 0; c.weightx = 0;
        panel.add(new JLabel("Customer Name:"), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(txtName, c);

        c.gridx = 0; c.gridy = 1; c.weightx = 0;
        panel.add(new JLabel("Select Product:"), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(cmbProduct, c);

        c.gridx = 0; c.gridy = 2; c.weightx = 0;
        panel.add(new JLabel("Enter Price:"), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(txtPrice, c);

        c.gridx = 1; c.gridy = 3;
        panel.add(btnProcess, c);

        btnProcess.addActionListener(e -> processSale());
        add(panel);
    }

    // Q.2.3 - capture, calculate, show, save
    private void processSale() {
        String name = txtName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer's name.",
                    "Missing information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
            if (price <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price greater than 0.",
                    "Invalid price", JOptionPane.ERROR_MESSAGE);
            return;
        }

        IProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        String details = "Customer Name: " + name + "\n"
                       + "Product: " + product + "\n"
                       + "VAT: R " + vat + "\n"
                       + "COMMISSION: R " + commission + "\n"
                       + "TOTAL: R " + total;

        JOptionPane.showMessageDialog(this, details, "Message", JOptionPane.INFORMATION_MESSAGE);
        saveToFile(details);
    }

    private void saveToFile(String details) {
        // true = append, so each sale is added to the log
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println("DATA LOG");
            out.println("*******************************");
            out.println(details);
            out.println("*******************************");
            out.println();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not write to " + FILE_NAME + ": " + ex.getMessage(),
                    "File error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Q.2.4 - clear: text boxes empty, combo box index 0
    private void clearForm() {
        txtName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
        txtName.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
