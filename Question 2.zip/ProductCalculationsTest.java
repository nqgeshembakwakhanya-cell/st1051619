package productapp.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import productapp.ProductCalculations;

public class ProductCalculationsTest {

    private static final double DELTA = 0.001;

    // Unit Test 1 - verifies GetVat returns the correct VAT amount
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(525.0, calc.GetVat(), DELTA);
    }

    // The remaining tests follow the same pattern; match names/purposes to the paper (page 11+)
    @Test
    public void GetCommission_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(175.0, calc.GetCommission(), DELTA);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(4200.0, calc.GetTotal(), DELTA);
    }
}
