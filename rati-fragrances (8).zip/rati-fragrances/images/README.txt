Rati Fragrances - image assets
==============================

SOURCE ARTWORK (SVG)
--------------------
All artwork in this folder is original SVG created for this project. The SVG
files are the master copies: they are vector, so they stay sharp at any size
and are the files to edit if the artwork needs to change.

  logo.svg              Site logo, used in the header of all four pages
  favicon.svg           Browser tab icon
  hero-collection.svg   Master artwork for the homepage hero and About figure
  noir-royale.svg       Product artwork - Noir Royale
  golden-hour.svg       Product artwork - Golden Hour
  midnight-oud.svg      Product artwork - Midnight Oud
  rose-velvet.svg       Product artwork - Rose Velvet
  blue-horizon.svg      Product artwork - Blue Horizon
  vanilla-noir.svg      Product artwork - Vanilla Noir
  jasmine-bloom.svg     Product artwork - Jasmine Bloom
  amber-gold.svg        Product artwork - Amber Gold

RESPONSIVE RENDITIONS (JPG)
---------------------------
Added in Part 2. Each SVG was exported at several widths so that the browser
can download only the size it needs, using the srcset and sizes attributes.

  <name>-400.jpg              Product image at 400 x 300 - phones and small cards
  <name>-800.jpg              Product image at 800 x 600 - large or high-DPI screens

  hero-collection-400.jpg     Hero at 400 x 250   (8:5 composition)
  hero-collection-800.jpg     Hero at 800 x 500
  hero-collection-1200.jpg    Hero at 1200 x 750

  hero-collection-narrow-480.jpg   Hero, 4:3 crop at 480 x 360, phones only
  hero-collection-narrow-720.jpg   Hero, 4:3 crop at 720 x 540, phones only

The two "narrow" files are art direction rather than resolution switching: on a
phone the wide composition leaves the bottles too small, so index.html serves
the tighter crop through a <picture> element below 48em (768px).

REPLACING THESE WITH PHOTOGRAPHS
--------------------------------
Save each photograph at a 4:3 ratio in two widths, 400px and 800px, using the
same file names (for example noir-royale-400.jpg and noir-royale-800.jpg). No
HTML needs to change. Keep the alt text, but update it so it describes what the
new photograph actually shows.
