/* ==========================================================
   Rati Fragrances - site JavaScript
   Sections:
     1. Footer year
     2. Mobile navigation toggle
     3. Product search and category filter
     4. Customer review slider
     5. Contact form validation
   Every block checks the element exists first, so one file
   can safely be shared by all four pages.
   ========================================================== */

document.addEventListener("DOMContentLoaded", function () {

  /* ---------- 1. Footer year ---------- */
  var yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }


  /* ---------- 2. Mobile navigation toggle ---------- */
  var navToggle = document.getElementById("navToggle");
  var navMenu = document.getElementById("navMenu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      var isOpen = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
    });

    // Close the menu when a link is tapped
    navMenu.addEventListener("click", function (event) {
      if (event.target.tagName === "A") {
        navMenu.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }


  /* ---------- 3. Product search and category filter ---------- */
  var searchInput = document.getElementById("productSearch");
  var productGrid = document.getElementById("productGrid");
  var filterButtons = document.querySelectorAll(".filter-btn");
  var resultCount = document.getElementById("resultCount");
  var emptyState = document.getElementById("emptyState");

  if (productGrid) {
    var cards = productGrid.querySelectorAll(".product-card");
    var activeCategory = "all";

    function applyFilters() {
      var term = searchInput ? searchInput.value.trim().toLowerCase() : "";
      var visible = 0;

      cards.forEach(function (card) {
        var category = card.getAttribute("data-category");
        var keywords = (card.getAttribute("data-name") || "").toLowerCase();

        var matchesCategory = activeCategory === "all" || category === activeCategory;
        var matchesSearch = term === "" || keywords.indexOf(term) !== -1;

        if (matchesCategory && matchesSearch) {
          card.hidden = false;
          visible++;
        } else {
          card.hidden = true;
        }
      });

      if (resultCount) {
        resultCount.textContent =
          visible === 1 ? "1 fragrance" : visible + " fragrances";
      }

      if (emptyState) {
        emptyState.hidden = visible !== 0;
      }
    }

    if (searchInput) {
      searchInput.addEventListener("input", applyFilters);
    }

    filterButtons.forEach(function (button) {
      button.addEventListener("click", function () {
        filterButtons.forEach(function (b) { b.classList.remove("is-active"); });
        button.classList.add("is-active");
        activeCategory = button.getAttribute("data-filter");
        applyFilters();
      });
    });

    applyFilters(); // show the starting count
  }


  /* ---------- 4. Customer review slider ---------- */
  var reviews = document.querySelectorAll(".review");
  var nextBtn = document.getElementById("nextReview");
  var prevBtn = document.getElementById("prevReview");

  if (reviews.length > 0 && nextBtn && prevBtn) {
    var current = 0;

    function showReview(index) {
      reviews.forEach(function (review) { review.classList.remove("is-active"); });
      reviews[index].classList.add("is-active");
    }

    nextBtn.addEventListener("click", function () {
      current = (current + 1) % reviews.length;
      showReview(current);
    });

    prevBtn.addEventListener("click", function () {
      current = (current - 1 + reviews.length) % reviews.length;
      showReview(current);
    });
  }


  /* ---------- 5. Contact form validation ---------- */
  var form = document.getElementById("contactForm");

  if (form) {
    var formStatus = document.getElementById("formStatus");

    function setError(inputId, message) {
      var input = document.getElementById(inputId);
      var errorBox = document.getElementById(inputId + "Error");
      if (errorBox) { errorBox.textContent = message; }
      if (input) { input.classList.toggle("has-error", message !== ""); }
      return message === "";
    }

    form.addEventListener("submit", function (event) {
      event.preventDefault(); // no back-end yet, so handle it here

      var name = document.getElementById("name").value.trim();
      var email = document.getElementById("email").value.trim();
      var phone = document.getElementById("phone").value.trim();
      var message = document.getElementById("message").value.trim();

      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
      var phonePattern = /^[0-9+\s()-]{10,15}$/;

      var valid = true;

      valid = setError("name", name.length < 2 ? "Enter your full name." : "") && valid;
      valid = setError("email", !emailPattern.test(email) ? "Enter a valid email address, for example name@example.com." : "") && valid;
      valid = setError("phone", phone !== "" && !phonePattern.test(phone) ? "Enter a valid phone number, or leave this blank." : "") && valid;
      valid = setError("message", message.length < 10 ? "Tell us a little more - at least 10 characters." : "") && valid;

      if (!valid) {
        formStatus.textContent = "Please fix the highlighted fields and send again.";
        formStatus.classList.remove("is-success");
        return;
      }

      formStatus.textContent = "Thank you, " + name + ". Your message has been received and we will reply within one working day.";
      formStatus.classList.add("is-success");
      form.reset();
    });
  }

});
