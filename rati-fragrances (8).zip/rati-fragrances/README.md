# Rati Fragrances — Website

**Module:** WEDE5020 — Web Development (Introduction)
**Portfolio of Evidence:** Part 2 — CSS styling and responsive design
**Organisation:** Rati Fragrances, established September 2020 by Athabile Rati Methedeni
**Live files:** `index.html`, `about.html`, `products.html`, `contact.html`

Rati Fragrances is a small South African business selling quality, affordable and
long-lasting fragrances. This repository holds the website built for the business
across the Portfolio of Evidence. The business history, mission, vision, product
range and pricing shown on the site were supplied by the organisation itself
(Rati Fragrances, 2026). Part 1 delivered the HTML structure and content. Part 2,
following the requirements set out by The Independent Institute of Education
(2026), adds a single external stylesheet, a complete desktop design and a
responsive layout that works on tablets and phones.

---

## Table of contents

1. [Pages](#1-pages)
2. [Folder structure](#2-folder-structure)
3. [How to view the site](#3-how-to-view-the-site)
4. [Part 2: CSS styling for the desktop solution](#4-part-2-css-styling-for-the-desktop-solution)
5. [Part 2: Responsive design](#5-part-2-responsive-design)
6. [Screenshot evidence across screen sizes](#6-screenshot-evidence-across-screen-sizes)
7. [Testing with browser developer tools](#7-testing-with-browser-developer-tools)
8. [Accessibility](#8-accessibility)
9. [JavaScript functionality](#9-javascript-functionality)
10. [Changelog](#10-changelog)
11. [Still to do](#11-still-to-do)
12. [Reference list](#12-reference-list)

---

## 1. Pages

| File | Purpose |
|---|---|
| `index.html` | Homepage — hero, featured fragrances, about summary, why choose us, customer reviews, call to action |
| `about.html` | Organisation history, mission, vision and values |
| `products.html` | Full product range with live search and category filtering |
| `contact.html` | Enquiry form with validation, contact details and trading hours |

---

## 2. Folder structure

```
/
├── index.html
├── about.html
├── products.html
├── contact.html
├── README.md
├── css/
│   └── style.css              ← the single external stylesheet for all four pages
├── js/
│   └── script.js
├── images/
│   ├── logo.svg               ← original SVG artwork (source files)
│   ├── favicon.svg
│   ├── hero-collection.svg
│   ├── noir-royale.svg  … amber-gold.svg
│   ├── hero-collection-400.jpg / -800.jpg / -1200.jpg        ← srcset renditions
│   ├── hero-collection-narrow-480.jpg / -720.jpg             ← mobile art direction
│   ├── noir-royale-400.jpg / -800.jpg  … (one pair per product)
│   └── README.txt
└── readme-images/             ← screenshot evidence used in this README
    ├── desktop-index.jpg, tablet-index.jpg, mobile-index.jpg
    └── … one set per page
```

---

## 3. How to view the site

1. Download or clone the repository.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox or Safari).
3. No build step, server, framework or library is needed. The only external
   resource is the Google Fonts stylesheet, so an internet connection is required
   for Playfair Display and Poppins to display; without it the browser falls back
   to Georgia and Helvetica, which are declared in the font stacks.

---

## 4. Part 2: CSS styling for the desktop solution

### 4.1 External stylesheet

All styling lives in one external stylesheet, `css/style.css`, linked from the
`<head>` of all four pages:

```html
<link rel="stylesheet" href="css/style.css">
```

There is no inline styling and no `<style>` block anywhere in the HTML, so the
presentation is fully separated from the structure. Class names follow one
convention throughout: lowercase and hyphenated (`.product-card`, `.footer-grid`),
with state classes prefixed `is-` (`.is-open`, `.is-active`). The stylesheet is
divided into 21 numbered and commented sections, listed in a contents block at the
top of the file.

### 4.2 Base styles and the CSS reset

Section 1 of the stylesheet is a reset. Browsers apply their own default margins,
padding and box model, and those defaults are not identical, so the reset clears
them before any design work begins. It sets `box-sizing: border-box` on every
element, removes default margins and padding, removes list bullets, makes images
block-level and capped at `max-width: 100%`, and makes form controls inherit the
site font. As Mozilla (2026b) explains, `border-box` sizing
means padding and borders are counted inside an element's declared width, which
makes layout arithmetic far more predictable.

Base styles are then set once on `body`: background colour, text colour, font
family, font size, font weight and line height.

### 4.3 Using the cascade to keep the selector count low

Font family, colour and line height are inherited properties, so declaring them
once on `body` styles every heading, paragraph, list, table and form control on
the site. Individual components only declare what actually differs from that
inherited baseline. Mozilla (2026a) describes this
inheritance behaviour as one of the core mechanisms of the cascade, and the
stylesheet leans on it deliberately: for example, no rule sets `font-family` on
paragraphs, list items or table cells anywhere in the file.

Two further techniques reduce the number of selectors:

- **Custom properties.** Every colour, type size, spacing step, border, shadow and
  transition speed is declared once in `:root` (section 2) and then referred to by
  name. Changing `--colour-gold` in one place restyles buttons, headings, borders,
  links, prices and focus rings across all four pages.
- **Grouped selectors.** One rule handles the focus style for links, buttons,
  inputs, selects and text areas; one rule handles both `.feature-grid` and
  `.statement-grid`.

### 4.4 Typography

The site uses two clearly distinct families, both loaded from Google Fonts (Google,
2026): Playfair Display, a serif, for headings, and Poppins, a sans-serif, for body
copy. Each has a fallback stack so the page still reads correctly if the web fonts
fail to load.

Type sizes follow a 1.25 (major third) modular scale rather than being picked one
at a time, which keeps the relationship between sizes consistent (Bringhurst, 2004):

| Token | Size | Used for |
|---|---|---|
| `--text-xs` | 0.8rem | Meta text, captions, legal line |
| `--text-sm` | 0.9rem | Navigation, buttons, card copy, footer |
| `--text-base` | 1rem | Body copy |
| `--text-md` | 1.25rem | `h3`, lead paragraphs, prices |
| `--text-lg` | 1.563rem | Review quotations |
| `--text-xl` | 1.953rem | Statistics in the fact list |
| `--text-2xl` | 2.441rem | `h2` |
| `--text-3xl` | 3.052rem | `h1` |

Every size is expressed in `rem` rather than `px`, so the whole scale grows if a
visitor raises their browser's default font size. Alongside size, the stylesheet
sets `font-family`, `font-weight` (300 for body, 500 for interface text, 700 for
headings), `line-height` (1.7 for body copy, 1.15 for headings) and
`letter-spacing` (a slight negative tracking on large serif headings, and 0.14em on
the small "Since 2020" kicker). Paragraph width is capped at `65ch` so lines stay
inside a comfortable reading measure.

### 4.5 Layout structure

Layout is built with CSS Grid and Flexbox, chosen per component according to
whether the problem is two-dimensional or one-dimensional (Mozilla, 2026c).

**Grid with named areas** (`grid-template-areas`) is used where naming the regions
makes the layout easier to read and to rearrange at a breakpoint:

| Component | Desktop areas |
|---|---|
| `body` page shell | `"masthead"` / `"content"` / `"colophon"` |
| `.hero-inner` | `"copy media"` |
| `.about-split` | `"story facts"` |
| `.contact-split` | `"enquiry details"` |
| `.footer-grid` | `"about pages contact social"` |

Because the areas are named, the mobile layouts in sections 19 and 20 of the
stylesheet only need to re-draw the ASCII-like area map; no HTML is touched and no
element is re-ordered by hand.

**Grid with `auto-fit` and `minmax()`** is used for the product grid and the feature
grid: `repeat(auto-fit, minmax(16rem, 1fr))` lets the browser fit three cards on a
desktop, two on a tablet and one on a phone without a media query at all.

**Flexbox** is used for one-dimensional rows: the navigation bar
(`display: flex; justify-content: space-between; align-items: center`), the hero
button row, the filter bar, the review controls and the inside of each product card
(`flex-direction: column` with `margin-top: auto` on the button so that buttons
align along the bottom edge of a row of cards regardless of description length).

### 4.6 Visual styling

- `background-color` and `color` alternate light cream and near-black sections to
  separate the page into readable bands.
- `border` is used as a structural signal rather than decoration: a gold hairline
  under section headings, a gold rule above each feature, and a gold left border on
  the contact details column that moves to the top edge when the column goes full
  width.
- `box-shadow` is applied in three deliberate places — a very soft resting shadow
  on product cards, a stronger lift on hover and on the hero image, and a gold glow
  used as the focus ring on form fields.
- Pseudo-classes cover every interactive state: `:hover` for pointer feedback,
  `:focus-visible` for a visible keyboard outline on links, buttons and every form
  control, and `:active` for a one-pixel press on buttons. `::after` draws the gold
  rule under section headings without any extra markup, and `::selection` styles
  highlighted text in the brand gold.

---

## 5. Part 2: Responsive design

### 5.1 Breakpoints

The desktop design is written first, then three `max-width` media queries adapt it
downwards. Breakpoints are declared in `em` so that they respond to the visitor's
own font size as well as to the viewport width (Frain, 2022).

| Breakpoint | Query | Target | What changes |
|---|---|---|---|
| 1 | `max-width: 64em` (1024px) | Tablet landscape, small laptop | Heading scale steps down, hero columns become an even split, section padding and navigation gaps tighten |
| 2 | `max-width: 48em` (768px) | Tablet portrait | Navigation collapses into the hamburger panel; hero, about, contact and footer grids switch from multi-column to single-column; the contact rule moves from the left edge to the top; the filter bar stacks |
| 3 | `max-width: 30em` (480px) | Mobile phone | Type scale steps down again, the product grid becomes one card per row, the footer becomes a single column, hero buttons go full width for thumbs, and the logo shrinks |

The multi-column to single-column switch required by the brief happens at
breakpoint 2 and is done by rewriting the named grid areas, for example:

```css
/* Desktop */
.footer-grid { grid-template-areas: "about pages contact social"; }

/* max-width: 48em */
.footer-grid {
  grid-template-areas:
    "about about"
    "pages contact"
    "social social";
}

/* max-width: 30em */
.footer-grid {
  grid-template-areas: "about" "pages" "contact" "social";
}
```

Font sizes are changed per breakpoint by redefining the type tokens inside the
media query rather than by restyling each heading, so one declaration resizes every
`h1` on the site.

### 5.2 Relative units

No layout value in the stylesheet is a fixed pixel width. The site uses:

- **`rem`** for all font sizes, spacing, radii and container widths, so everything
  scales with the browser's base font size;
- **`em`** for breakpoints and for letter-spacing, which is relative to the element's
  own size;
- **`%`** and `1fr` for element widths, including `width: 100%` on images, form
  fields and the container;
- **`vw`** in the `sizes` attribute of responsive images, and `100vh` for the minimum
  page height;
- **`ch`** for the reading measure, which ties line length to the actual width of the
  characters being displayed.

Pixels appear only for hairline borders and the two-pixel accent rules, where a
fixed hairline is the intended result.

### 5.3 Responsive images

Product images use `srcset` with width descriptors and a `sizes` attribute, so the
browser downloads the 400px file on a phone and the 800px file on a large display
instead of sending one large file to everyone:

```html
<img src="images/noir-royale-400.jpg"
     srcset="images/noir-royale-400.jpg 400w,
             images/noir-royale-800.jpg 800w"
     sizes="(max-width: 48em) 90vw, (max-width: 64em) 44vw, 340px"
     alt="Noir Royale bottle, a dark amber fragrance in a gold-trimmed 50ml bottle"
     width="400" height="300" loading="lazy" decoding="async">
```

The hero uses the `<picture>` element for art direction, which is a different
problem from resolution switching: on a phone the wide 8:5 composition leaves the
bottles too small, so a tighter 4:3 crop is served instead, and each source offers
two resolutions.

```html
<picture class="hero-media">
  <source media="(max-width: 48em)"
          srcset="images/hero-collection-narrow-480.jpg 480w,
                  images/hero-collection-narrow-720.jpg 720w"
          sizes="90vw">
  <img class="hero-image" src="images/hero-collection-800.jpg"
       srcset="images/hero-collection-400.jpg 400w,
               images/hero-collection-800.jpg 800w,
               images/hero-collection-1200.jpg 1200w"
       sizes="(max-width: 64em) 90vw, 46vw"
       alt="Three Rati Fragrances bottles in amber, rose and blue, arranged together"
       width="800" height="500" fetchpriority="high">
</picture>
```

Mozilla (2026d) sets out this distinction between resolution switching with
`srcset` and art direction with `<picture>`, and both techniques are used here for
the case each is intended for. Every image also carries explicit `width` and
`height` attributes so the browser can reserve the right space before the file
arrives, `alt` text describing what the image shows, and `loading="lazy"` on
everything below the fold.

---

## 6. Screenshot evidence across screen sizes

All screenshots were captured in Chromium using the device toolbar in the browser
developer tools, at the viewport sizes listed below.

| Label | Viewport | Represents |
|---|---|---|
| Desktop | 1440 × 900 | Laptop or desktop monitor |
| Tablet | 768 × 1024 | iPad / Android tablet, portrait |
| Mobile | 390 × 844 | iPhone 14 / modern Android phone |

### Homepage

| Desktop (1440px) | Tablet (768px) | Mobile (390px) |
|---|---|---|
| ![Homepage on desktop](readme-images/desktop-index.jpg) | ![Homepage on tablet](readme-images/tablet-index.jpg) | ![Homepage on mobile](readme-images/mobile-index.jpg) |

The hero is two columns on desktop, stacks to one column on tablet, and on mobile
switches to the cropped hero image with full-width buttons.

### About page

| Desktop (1440px) | Tablet (768px) | Mobile (390px) |
|---|---|---|
| ![About page on desktop](readme-images/desktop-about.jpg) | ![About page on tablet](readme-images/tablet-about.jpg) | ![About page on mobile](readme-images/mobile-about.jpg) |

### Products page

| Desktop (1440px) | Tablet (768px) | Mobile (390px) |
|---|---|---|
| ![Products page on desktop](readme-images/desktop-products.jpg) | ![Products page on tablet](readme-images/tablet-products.jpg) | ![Products page on mobile](readme-images/mobile-products.jpg) |

The product grid shows three cards per row on desktop, two on tablet and one on
mobile, and the search and filter bar stacks below 768px.

### Contact page

| Desktop (1440px) | Tablet (768px) | Mobile (390px) |
|---|---|---|
| ![Contact page on desktop](readme-images/desktop-contact.jpg) | ![Contact page on tablet](readme-images/tablet-contact.jpg) | ![Contact page on mobile](readme-images/mobile-contact.jpg) |

The form and the contact details sit side by side on desktop; below 768px the
details column moves underneath the form and its gold rule moves from the left edge
to the top edge.

---

## 7. Testing with browser developer tools

The following checks were carried out in the Chrome and Edge developer tools while
building Part 2:

- **Device toolbar** (Ctrl + Shift + M) was used to step through 1440px, 1024px,
  768px, 480px and 360px and to confirm that each breakpoint takes effect where it
  is meant to, with no horizontal scrollbar at any width.
- **The Elements and Styles panels** were used to inspect which rule was winning on
  an element and to check the computed value of the custom properties at each
  breakpoint, which is how the stacked search field bug in the changelog below was
  found and fixed.
- **The Network panel**, with the cache disabled and throttling enabled, was used to
  confirm which image file is actually downloaded at each width. At 390px the hero
  loads the cropped `hero-collection-narrow-480.jpg`; at 1440px it loads
  `hero-collection-800.jpg`. Product cards load the 400px file on a standard
  display and the 800px file once the device pixel ratio is 2, which is the
  behaviour `srcset` is meant to produce.
- **The Lighthouse and Rendering panels** were used to check colour contrast, and the
  emulated `prefers-reduced-motion` setting was used to confirm that transitions
  are suppressed for visitors who ask for reduced motion.

---

## 8. Accessibility

- Semantic elements throughout (`header`, `nav`, `main`, `section`, `article`,
  `figure`, `footer`).
- A visible gold focus outline on every link, button and form control, never
  removed without a replacement.
- Body and heading colours were chosen to meet the WCAG 2.1 AA contrast minimum of
  4.5:1 for normal text (W3C, 2018).
- ARIA attributes on the navigation toggle (`aria-expanded`, `aria-controls`) and
  live regions for the search result count and the form status message.
- Descriptive `alt` text on every image, and `prefers-reduced-motion` respected.

---

## 9. JavaScript functionality

Carried over from Part 1 and unchanged in behaviour:

1. **Mobile navigation** — the hamburger button toggles the `.is-open` class on the
   menu and keeps `aria-expanded` in step.
2. **Product search** — filters the product grid live as you type, matching name and
   fragrance notes.
3. **Category filter** — All / Women / Men / Unisex, combined with the search term.
4. **Review slider** — previous and next buttons cycle the customer reviews.
5. **Form validation** — checks name, email format, optional phone format and
   message length before showing a confirmation.
6. **Footer year** — sets the copyright year automatically.

---

## 10. Changelog

Entries are newest first. Version 2.0 covers the Part 2 submission.

### Corrections made in response to Part 1 feedback

> **Note to self before submitting:** add one entry here for each specific comment
> on the Part 1 feedback sheet, stating what the comment was, what was changed, and
> which file was edited. The entries below cover the corrections made so far.

| Date | Feedback point addressed | Change made | Files |
|---|---|---|---|
| 2026-09-18 | Presentation was still unstyled browser default in places, so the brand was not visible | Replaced the Part 1 stylesheet with a fully documented one built on a reset, design tokens and a type scale | `css/style.css` |
| 2026-09-18 | Images were single fixed-size assets | Added multi-resolution renditions with `srcset` and `sizes`, plus a `<picture>` element for the hero | `index.html`, `products.html`, `about.html`, `images/` |
| 2026-09-18 | Layout containers were identified only by position, which made restyling awkward | Added descriptive classes (`.hero-copy`, `.footer-pages`, `.contact-form-block` and others) so every layout region can be targeted by name | all four HTML pages |
| 2026-09-18 | Reference list needed in-text citations to match it | Rewrote the README so every source in the reference list is cited in the text where it is used, in Harvard style | `README.md` |

### Version 2.0 — 18 September 2026 (Part 2)

**Stylesheet**

- Rebuilt `css/style.css` as a 21-section documented stylesheet with a contents
  block at the top.
- Added a CSS reset (`box-sizing: border-box`, zeroed margins and padding, list
  styles removed, images made block-level and fluid, form controls inheriting the
  page font) so that the site renders consistently across browsers.
- Introduced a full design-token system in `:root`: 12 colour tokens, 2 font
  stacks, an 8-step type scale, 7 spacing steps, plus border, shadow and
  transition tokens. Every later rule refers to these tokens instead of hard-coded
  values.
- Replaced the ad-hoc `clamp()` font sizes with a 1.25 modular scale in `rem`, and
  set explicit `font-weight`, `line-height` and `letter-spacing` values.
- Converted the page shell, hero, about split, contact split and footer from
  column-count grids to named `grid-template-areas`, so each breakpoint redefines
  a readable area map instead of repositioning individual elements.
- Added `box-shadow` (resting, hover-lift and focus-glow), a `::after` accent rule
  on section headings, a `::selection` colour, and `:active` press states on every
  button.
- Added a print stylesheet that hides the header, footer and call-to-action bar.

**Responsive design**

- Replaced the previous two pixel breakpoints with three `em`-based breakpoints at
  64em, 48em and 30em, each with a comment explaining what it is for.
- The type scale is now stepped down inside each media query by redefining the
  tokens, so heading sizes change site-wide from one declaration.
- Product grid now reduces from three columns to two to one; the footer goes from
  four columns to a 2 × 3 area map to a single column.
- Hero action buttons become full width below 30em for easier tapping.

**Images**

- Generated 400px and 800px JPEG renditions of all eight product images and 400px,
  800px and 1200px renditions of the hero from the original SVG artwork.
- Generated a cropped 4:3 version of the hero at 480px and 720px for phones.
- Added `srcset`, `sizes`, `decoding="async"` and `fetchpriority` attributes; kept
  the original SVG files in the repository as the source artwork.

**Fixes found during testing**

- Fixed product cards staying on screen after being filtered out. The search and
  filter script hides a card by setting its `hidden` attribute, but the card is
  also styled with `display: flex`, and a later `display` declaration overrides the
  browser's default `[hidden] { display: none }`. The result count said "0
  fragrances" while cards were still visible. A `[hidden] { display: none
  !important; }` rule was added to the reset so that the attribute always wins.
- Fixed the search field stretching to 16rem tall when the filter bar stacked below
  768px: the flex basis was being applied to height once `flex-direction` became
  `column`, so the basis is now reset in that media query.
- Fixed the hero image overflowing its column on narrow tablets by adding
  `max-width: 100%` and `height: auto` to all images in the reset.

**Documentation**

- Rewrote `README.md` with a table of contents, a description of the Part 2 CSS and
  responsive work, screenshot evidence at three screen sizes for all four pages, a
  developer-tools testing record, this changelog, and an expanded reference list
  with matching in-text citations.

### Version 1.0 — Part 1

- Built the four HTML pages with semantic structure and the organisation's content.
- Added original SVG artwork for the logo, favicon, hero and eight products.
- Added `js/script.js` with the navigation toggle, product search, category filter,
  review slider, form validation and footer year.

---

## 11. Still to do

- Replace the placeholder phone number and email address, which appear in the
  footer of all four pages and in the contact details on `contact.html`.
- Add the real Instagram, Facebook and TikTok URLs, currently `href="#"`.
- Connect the enquiry form to a back-end or form service; it currently validates
  and confirms in the browser only.
- Optionally replace the SVG product artwork with photographs of the actual
  bottles, keeping the same file names and the same `srcset` widths.

---

## 12. Reference list

Bringhurst, R. (2004) *The elements of typographic style*. 3rd edn. Point Roberts,
WA: Hartley & Marks.

Frain, B. (2022) *Responsive web design with HTML5 and CSS*. 4th edn. Birmingham:
Packt Publishing.

Google (2026) *Google Fonts*. Available at: https://fonts.google.com (Accessed:
18 September 2026).

Mozilla (2026a) *Cascade, specificity and inheritance*. MDN Web Docs. Available at:
https://developer.mozilla.org/en-US/docs/Learn/CSS/Building_blocks/Cascade_and_inheritance
(Accessed: 18 September 2026).

Mozilla (2026b) *The box model*. MDN Web Docs. Available at:
https://developer.mozilla.org/en-US/docs/Learn/CSS/Building_blocks/The_box_model
(Accessed: 18 September 2026).

Mozilla (2026c) *CSS grid layout*. MDN Web Docs. Available at:
https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout (Accessed:
18 September 2026).

Mozilla (2026d) *Responsive images*. MDN Web Docs. Available at:
https://developer.mozilla.org/en-US/docs/Web/HTML/Responsive_images (Accessed:
18 September 2026).

Rati Fragrances (2026) *Business and product information*. Johannesburg:
Rati Fragrances [organisational documentation].

The Independent Institute of Education (2026) *WEDE5020 portfolio of evidence:
Part 2 brief*. Johannesburg: The IIE.

W3C (2018) *Web content accessibility guidelines (WCAG) 2.1*. Available at:
https://www.w3.org/TR/WCAG21/ (Accessed: 18 September 2026).
